/**
 * Exam is built from ocr.pdf (same folder as index.html).
 * Text-based PDFs: text is read with PDF.js. Scanned PDFs: pages are OCR’d with Tesseract.
 * MCQ format: numbered questions (1. 2. …), options (a)–(d), optional Answer: B, optional Hint: …
 */
const EXAM_PDF_FILENAME = "ocr.pdf";

/**
 * Embedded copy of ocr.pdf (see embedded-ocr-pdf.js) so opening index.html from disk (file://) still works.
 */
function arrayBufferFromEmbeddedOcrPdf() {
    if (typeof EMBEDDED_OCR_PDF_BASE64 === "undefined" || !EMBEDDED_OCR_PDF_BASE64) return null;
    try {
        const bin = atob(EMBEDDED_OCR_PDF_BASE64);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return bytes.buffer;
    } catch (e) {
        return null;
    }
}

/** Used if the PDF has no extractable / parseable MCQs so the exam can still run. */
const SAMPLE_QUESTIONS = [
    {
        question: "The sum of the first five multiples of 6 is:",
        options: ["30", "60", "90", "120"],
        answer: "90",
        hint: "First five multiples: 6, 12, 18, 24, 30 — add them."
    },
    {
        question: "Which is the only number having only one factor?",
        options: ["0", "1", "2", "3"],
        answer: "1",
        hint: "Only 1 divides this number."
    },
    {
        question: "Which of the following numbers is not divisible by 3?",
        options: ["3162", "5482", "7956", "8085"],
        answer: "5482",
        hint: "Sum of digits must be divisible by 3 for divisibility by 3."
    },
    {
        question: "Two consecutive prime numbers whose difference is 2 are called:",
        options: ["Twin primes", "Co-primes", "Even numbers", "Composite numbers"],
        answer: "Twin primes",
        hint: "Pairs like 3 and 5, 5 and 7 have this name."
    },
    {
        question: "Which of the following is not correctly matched?",
        options: [
            "Only even number which is prime -> 2",
            "Smallest composite number -> 1",
            "Multiple of every number -> 0",
            "Factor of every number -> 1"
        ],
        answer: "Smallest composite number -> 1",
        hint: "1 is not composite; smallest composite is 4."
    },
    {
        question: "The prime factorisation of 88 is:",
        options: ["2 x 2 x 11", "2 x 44", "2 x 22 x 2", "2 x 2 x 2 x 11"],
        answer: "2 x 2 x 2 x 11",
        hint: "88 = 8 × 11; write 8 as powers of 2."
    },
    {
        question: "How many prime numbers are there from 1 to 100?",
        options: ["18", "22", "25", "27"],
        answer: "25",
        hint: "There are 25 primes not exceeding 100."
    },
    {
        question: "There are 3 prime numbers between:",
        options: ["40 and 50", "50 and 60", "70 and 80", "Both (a) and (c)"],
        answer: "Both (a) and (c)",
        hint: "Count primes in 40–50 and in 70–80."
    }
];

function enableLoginControls(canStart) {
    const userEl = document.getElementById("username");
    const classEl = document.getElementById("class");
    const startBtn = document.getElementById("startBtn");
    [userEl, classEl, startBtn].forEach((el) => {
        if (!el) return;
        if (canStart) {
            el.removeAttribute("disabled");
            el.disabled = false;
        } else {
            el.disabled = true;
            el.setAttribute("disabled", "disabled");
        }
    });
}

function escapeHtml(str) {
    if (str == null) return "";
    const d = document.createElement("div");
    d.textContent = str;
    return d.innerHTML;
}

let questions = [];

let currentQuestion = 0;
let score = 0;

let studentName = "";
let studentClass = "";

let userAnswers = [];

let attempt = 1;
let maxAttempts = 2;
/** Hints (Show hint) only on retake, not on the first attempt. */
let isRetake = false;

let hintUsed = [];
let hintCount = 0;

let correct = 0;
let wrong = 0;

function examTimeSeconds() {
    return Math.max(60, questions.length * 60);
}

let timeLeft = 60;
let timer = null;

function resetAttemptArrays() {
    userAnswers = new Array(questions.length).fill(null);
    hintUsed = new Array(questions.length).fill(false);
}

function parseOcrTextToQuestions(text) {
    const normalized = text.replace(/\r/g, "\n").replace(/\u00a0/g, " ");
    const re = /(?:^|\n)\s*(?:Q\s*)?(\d+)\s*[.)]\s*([\s\S]*?)(?=\n\s*(?:Q\s*)?\d+\s*[.)]\s|$)/gi;
    const out = [];
    let m;
    while ((m = re.exec(normalized)) !== null) {
        let body = (m[2] || "").trim();
        if (!body) continue;

        let answerKey = null;
        const ansMatch = body.match(/\n\s*(?:Answer|Ans|Key)\s*[:.)]\s*\(?([a-dA-D])\)?\s*$/im);
        if (ansMatch) {
            answerKey = ansMatch[1].toUpperCase();
            body = body.slice(0, ansMatch.index).trim();
        }

        let hint = "";
        const hintMatch = body.match(/\n\s*hint\s*[:.)]\s*\n?\s*([\s\S]+)$/im);
        if (hintMatch) {
            hint = hintMatch[1].trim();
            body = body.slice(0, hintMatch.index).trim();
        }

        const split = splitQuestionAndOptions(body);
        if (!split || split.options.length < 4) continue;

        const opts = split.options.slice(0, 4);
        let answer = opts[0];
        if (answerKey) {
            const idx = answerKey.charCodeAt(0) - 65;
            if (idx >= 0 && idx < 4) answer = opts[idx];
        }

        let qText = split.question.replace(/^\d+\s*[.)]\s*/, "").trim() || split.question;
        out.push({
            question: qText,
            options: opts,
            answer: answer,
            hint: hint || ""
        });
    }
    return out;
}

function parseOcrTextToQuestionsRelaxed(text) {
    const normalized = text
        .replace(/\r/g, "\n")
        .replace(/\u00a0/g, " ")
        .replace(/\n{3,}/g, "\n\n");
    return parseOcrTextToQuestions(normalized);
}

/**
 * True if the line starts an MCQ option (a) b) …), not English text like "A number is …".
 * Old pattern wrongly treated "A " + space as option (a).
 */
function lineLooksLikeMcqOptionLabel(line) {
    const s = String(line).trim();
    return /^(?:\([a-d]\)\s*|[a-d]\s*[.)]\s*|[A-D]\))/.test(s);
}

function splitQuestionAndOptions(body) {
    const lines = body.split("\n").map((l) => l.trim()).filter((l) => l.length > 0);
    let firstOpt = -1;
    for (let i = 0; i < lines.length; i++) {
        if (lineLooksLikeMcqOptionLabel(lines[i])) {
            firstOpt = i;
            break;
        }
    }

    if (firstOpt === -1) {
        return splitInlineOptions(body);
    }

    const question = lines.slice(0, firstOpt).join("\n").trim();
    const optText = lines.slice(firstOpt).join("\n");
    let opts = extractOptionsFromBlock(optText);
    if (opts.length < 4) opts = extractOptionsFromBlock(optText.replace(/\n/g, " "));
    if (opts.length < 4) return splitInlineOptions(body);
    return { question: question || "Question", options: opts };
}

function splitInlineOptions(body) {
    const parts = body.split(/\s*(?=\([a-d]\)\s*|[a-d]\s*[.)]\s*|[A-D]\)\s*)/);
    const trimmed = parts.map((p) => p.trim()).filter(Boolean);
    if (trimmed.length < 5) return null;
    const q = trimmed[0].replace(/\s+$/, "").trim();
    const opts = [];
    for (let i = 1; i <= 4 && i < trimmed.length; i++) {
        const mm = trimmed[i].match(/^\(?[a-dA-D]\)?[\s.)]\s*(.+)$/i);
        opts.push(mm ? mm[1].trim() : trimmed[i]);
    }
    if (opts.length < 4) return null;
    return { question: q || "Question", options: opts };
}

function extractOptionsFromBlock(optText) {
    const opts = [];
    const re = /\(?([a-dA-D])\)?[\s.)]\s*([\s\S]*?)(?=\s*(?:\n\s*)?\(?[a-dA-D]\)?[\s.)]|$)/gi;
    let mm;
    while ((mm = re.exec(optText)) !== null) {
        const letter = String(mm[1]).toUpperCase();
        if (letter < "A" || letter > "D") continue;
        opts.push(String(mm[2]).trim().replace(/\s+/g, " "));
    }
    return opts;
}

function normalizePdfText(t) {
    return t.replace(/\r/g, "\n").replace(/[ \t\f\v]+/g, " ").replace(/\n{3,}/g, "\n\n");
}

/**
 * PDF.js gives many small strings; joining with spaces only loses line breaks.
 * Rebuild lines using y-position so "1." / "a)" / "2." land on sensible lines for parsing.
 */
function pageTextFromPdfItems(textContent) {
    const items = textContent.items;
    if (!items || items.length === 0) return "";

    const withPos = items.map((item) => {
        const tr = item.transform || [0, 0, 0, 0, 0, 0];
        const x = tr[4];
        const y = tr[5];
        return { str: item.str || "", x, y };
    });

    withPos.sort((a, b) => {
        if (Math.abs(a.y - b.y) > 2.5) return b.y - a.y;
        return a.x - b.x;
    });

    const lines = [];
    let line = [];
    let lastY = null;
    const yThreshold = 6;

    for (const it of withPos) {
        if (lastY !== null && Math.abs(it.y - lastY) > yThreshold) {
            if (line.length) lines.push(line.join(" "));
            line = [];
        }
        line.push(it.str);
        lastY = it.y;
    }
    if (line.length) lines.push(line.join(" "));

    return lines.join("\n");
}

/** Insert newlines before "2." "3." … when PDF text has no line breaks between questions */
function preprocessExamTextForMcq(text) {
    let t = text.replace(/\r/g, "\n");
    // Do not split on "5." when it follows "by" (e.g. "divisible by 5." — otherwise Q5 breaks apart).
    t = t.replace(/([^\n])\s+((?:\d{1,2})\s*[.)]\s)/g, (match, ch, numPart, offset, str) => {
        const upto = str.slice(0, offset + ch.length);
        if (/\bby$/i.test(upto)) return match;
        return ch + "\n" + numPart;
    });
    return t.replace(/\n{3,}/g, "\n\n").trim();
}

/**
 * PDFs often split "10." across two lines as "1" then "0." so Q10 merges into Q1 or gets wrong options.
 * Merge only the common "1" + "0." → "10." case at line boundaries.
 */
function fixSplitQuestionNumberTen(text) {
    return text.replace(/(^|\n)1\s*\n\s*0(\s*[.)]\s)/g, (_, p1, p2) => p1 + "10" + p2);
}

/**
 * Map question number → block body from text already normalized for MCQ parsing.
 */
function mapNumberedQuestionBlocksFromProcessedText(t) {
    if (!t) return Object.create(null);
    const blocks = t.split(/\n(?=\s*\d{1,3}\s*[.)]\s)/);
    const map = Object.create(null);
    for (const raw of blocks) {
        const m = raw.trim().match(/^(\d{1,3})\s*[.)]\s*([\s\S]*)$/);
        if (m) map[parseInt(m[1], 10)] = m[2].trim();
    }
    return map;
}

function extractHintFromBlockBody(block) {
    if (!block || !String(block).trim()) return "";
    let hint = "";
    const beforeAnswer = block.match(/\n\s*Hint\s*[:.)]\s*([\s\S]+?)(?=\n\s*(?:Answer|Ans|Key)\s*[:.)])/i);
    if (beforeAnswer) hint = beforeAnswer[1].trim();
    if (!hint) {
        const tail = block.match(/\n\s*Hint\s*[:.)]\s*([\s\S]+)$/i);
        if (tail) {
            hint = tail[1].trim().replace(/\n\s*(?:Answer|Ans|Key)\s*[:.)]\s*[\s\S]*$/i, "").trim();
        }
    }
    if (!hint) {
        const start = block.match(/^\s*Hint\s*[:.)]\s*([\s\S]+)$/im);
        if (start) hint = start[1].trim();
    }
    return hint.replace(/\n{3,}/g, "\n").trim();
}

function extractAnswerLetterFromBlockBody(block) {
    if (!block) return null;
    const m = block.match(/\n\s*(?:Answer|Ans|Key)\s*[:.)]\s*\(?([a-dA-D])\)?/im);
    return m ? m[1].toUpperCase() : null;
}

/**
 * Attach Hint: / Answer: from raw PDF text when the main parser dropped them (fallback parsers use hint "").
 */
function supplementQuestionsFromRawBlocks(processedFullText, parsed) {
    if (!parsed || parsed.length === 0) return parsed;
    const map = mapNumberedQuestionBlocksFromProcessedText(processedFullText);
    for (let i = 0; i < parsed.length; i++) {
        const num = i + 1;
        const block = map[num];
        if (!block) continue;
        const hint = extractHintFromBlockBody(block);
        if (hint && !String(parsed[i].hint || "").trim()) parsed[i].hint = hint;
        const letter = extractAnswerLetterFromBlockBody(block);
        if (letter && parsed[i].options && parsed[i].options.length >= 4) {
            const idx = letter.charCodeAt(0) - 65;
            if (idx >= 0 && idx < 4) parsed[i].answer = parsed[i].options[idx];
        }
    }
    return parsed;
}

/** ocr.pdf Q5 — same fix as Q9–10 if extraction still mangles stem/options */
const OCR_PDF_Q5 = {
    question: "A number is divisible by 5 if:",
    options: [
        "Last digit is 0 or 5",
        "Sum of digits divisible by 5",
        "Product of digits divisible by 5",
        "None"
    ],
    answer: "Last digit is 0 or 5",
    hint: ""
};

/**
 * ocr.pdf: text extraction often drops or merges options for Q9–Q10. Canonical copy from the PDF
 * so all four options, answers, and retake hints are present.
 */
const OCR_PDF_Q9_Q10 = {
    9: {
        question: "The product of two co-prime numbers is:",
        options: [
            "Always even",
            "Always odd",
            "Equal to their LCM",
            "Equal to their HCF"
        ],
        answer: "Equal to their LCM",
        hint: "Co-prime numbers have HCF 1. For any two numbers, product = LCM × HCF, so the product equals their LCM."
    },
    10: {
        question: "Euclid's division lemma states:",
        options: ["a = bq + r", "a = b + r", "a = qr", "None"],
        answer: "a = bq + r",
        hint: "For integers a and b (b > 0), there are unique q and r with a = bq + r and 0 ≤ r < b."
    }
};

function patchOcrPdfQuestionsNineAndTen(qs) {
    if (!qs || qs.length < 10) return qs;
    if (qs.length >= 5) {
        const p5 = OCR_PDF_Q5;
        const stem4 = (qs[4].question || "").toLowerCase();
        const opt4 = qs[4].options || [];
        const need5 =
            opt4.length < 4 ||
            /divisible\s+by\s+5|divisibility.*\b5\b/.test(stem4) ||
            (/divisible/.test(stem4) && /(^|\s)5(\s|[:.]|$)/.test(stem4));
        if (need5) {
            qs[4] = {
                question: p5.question,
                options: p5.options.slice(),
                answer: p5.answer,
                hint: p5.hint
            };
        }
    }
    const p9 = OCR_PDF_Q9_Q10[9];
    const p10 = OCR_PDF_Q9_Q10[10];
    const stem8 = (qs[8].question || "").toLowerCase();
    const stem9 = (qs[9].question || "").toLowerCase();
    const opt8 = qs[8].options || [];
    const opt9 = qs[9].options || [];
    const need9 =
        opt8.length < 4 ||
        /co[-\s]?prime|coprime/.test(stem8) ||
        (/product/.test(stem8) && /two/.test(stem8) && /number/.test(stem8));
    const need10 = opt9.length < 4 || /euclid|division\s+lemma/.test(stem9);
    if (need9) {
        qs[8] = {
            question: p9.question,
            options: p9.options.slice(),
            answer: p9.answer,
            hint: p9.hint
        };
    }
    if (need10) {
        qs[9] = {
            question: p10.question,
            options: p10.options.slice(),
            answer: p10.answer,
            hint: p10.hint
        };
    }
    return qs;
}

/** Shown on retake when no specific hint exists for this exam length. */
const RETAKE_FALLBACK_HINT =
    "Read the question again, eliminate options that clearly do not fit, then choose the best match.";

/**
 * Hints for Class 10 Ch.1 Real Numbers MCQs in ocr.pdf (15 questions). Used when the loaded exam has 15 items.
 */
const OCR_EXAM_HINTS_15 = [
    "A prime has exactly two distinct factors: 1 and itself. Test each option for divisibility by small primes.",
    "√4 and √9 are whole numbers (rational). √2 cannot be written as a fraction of two integers.",
    "List the factors of 12 and of 18, then pick the largest number that appears in both lists.",
    "Multiples of 4: 4, 8, 12, … Multiples of 6: 6, 12, … Or use prime factorisation with the highest powers.",
    "Divisibility by 5 depends only on the last digit: it must be 0 or 5.",
    "A composite number has more than two factors. Check which option can be factored further.",
    "Write 1/8 as a decimal: divide 1 by 8. Denominators of the form 2^m×5^n give terminating decimals.",
    "A fraction has a terminating decimal only if the denominator (in lowest terms) is 2^a×5^b. Simplify each fraction first.",
    "Co-prime numbers have HCF 1. For any two numbers, product = LCM × HCF, so here the product equals their LCM.",
    "Euclid’s lemma: for positive integers a and b (b > 0), there are unique q and r with a = bq + r and 0 ≤ r < b.",
    "Co-prime means their only common factor is 1 — that is the definition of their HCF.",
    "Rational numbers can be written as p/q with integers q ≠ 0. Which option is a non-repeating, non-fraction square root?",
    "36 = 6² = (2×3)² — express it as a product of primes only.",
    "Each number divides its LCM, so the LCM cannot be smaller than either number (unless one is 0, not the case here).",
    "A number is divisible by 9 if and only if the sum of its digits is divisible by 9 — add the digits of each option."
];

/**
 * Ensures every question has hint text so “Show hint” works on retake. Full ocr.pdf (15 Q) uses OCR_EXAM_HINTS_15.
 */
function ensureRetakeHintsForAllQuestions(qs) {
    if (!qs || !qs.length) return qs;
    const use15 = qs.length === OCR_EXAM_HINTS_15.length;
    for (let i = 0; i < qs.length; i++) {
        const q = qs[i];
        if (use15 && OCR_EXAM_HINTS_15[i]) {
            q.hint = OCR_EXAM_HINTS_15[i];
        } else if (!String(q.hint || "").trim()) {
            q.hint = hintFromQuestionText(q.question) || `Q${i + 1}. ${RETAKE_FALLBACK_HINT}`;
        }
    }
    return qs;
}

function hintFromQuestionText(questionText) {
    const t = String(questionText || "").toLowerCase();
    if (!t) return "";

    // Polynomials
    if (t.includes("degree of the polynomial") || t.includes("degree of polynomial") || t.includes("degree of the")) {
        return "The degree is the highest power of x with a non-zero coefficient (after simplifying).";
    }
    if (t.includes("graph") && t.includes("linear polynomial")) {
        return "A linear polynomial has the form ax + b; its graph is a straight line.";
    }
    if (t.includes("number of zeroes") && t.includes("quadratic")) {
        return "A quadratic polynomial can have at most 2 zeroes (it can be 0, 1, or 2).";
    }
    if ((t.includes("zeroes") || t.includes("zeros")) && t.includes("then its zeroes are")) {
        return "Set p(x)=0 and solve the equation. For x² − 9, use difference of squares: x² − 3² = (x−3)(x+3).";
    }
    if (t.includes("value of p(2)") || t.includes("p(2)")) {
        return "Substitute x = 2 into p(x) and simplify.";
    }
    if ((t.includes("α") || t.includes("beta") || t.includes("zeroes of")) && t.includes("then") && t.includes("α + β")) {
        return "For ax² + bx + c, sum of zeroes α+β = −b/a.";
    }
    if (t.includes("product of zeroes")) {
        return "For ax² + bx + c, product of zeroes αβ = c/a.";
    }
    if (t.includes("is a factor") || t.includes("factor of p(x)")) {
        return "Factor Theorem: (x − a) is a factor of p(x) ⇔ p(a) = 0.";
    }
    if (t.includes("number of zeroes") && t.includes("cubic")) {
        return "A cubic polynomial can have at most 3 zeroes.";
    }
    if (t.includes("which of the following is a polynomial")) {
        return "In a polynomial, the power of x must be a whole number (0,1,2,...) and x cannot be in the denominator or under a root.";
    }

    if (t.includes("hcf") && t.includes("lcm") && (t.includes("equal") || t.includes("equals"))) {
        return "Use the identity: for two positive integers, HCF × LCM = product of the two numbers.";
    }
    if (t.includes("hcf of") || t.startsWith("the hcf")) {
        return "Find common factors of both numbers; the greatest common factor is the HCF (or use prime factorisation).";
    }
    if (t.includes("lcm of") || t.startsWith("the lcm")) {
        return "List multiples or use prime factorisation; take the highest power of each prime to get the LCM.";
    }
    if (t.includes("prime number") || t.includes("exactly two factors")) {
        return "A prime has exactly two factors: 1 and itself. Test each option for divisibility by small primes.";
    }
    if (t.includes("co-prime") || t.includes("coprime")) {
        if (t.includes("product")) {
            return "For any two numbers, product = LCM × HCF. Co-prime numbers have HCF 1, so product = LCM.";
        }
        if (t.includes("hcf")) {
            return "Co-prime numbers have no common factor except 1, so their HCF is 1.";
        }
    }
    if (t.includes("euclid") && t.includes("division")) {
        return "Euclid’s division lemma: a = bq + r with 0 ≤ r < b (b > 0). It’s used to find HCF efficiently.";
    }
    if (t.includes("decimal expansion")) {
        if (t.includes("1/3")) return "1/3 = 0.333… which is non‑terminating repeating.";
        if (t.includes("1/2")) return "1/2 = 0.5 which is terminating.";
        return "A rational number terminates iff the denominator (in lowest terms) has only prime factors 2 and/or 5.";
    }
    if (t.includes("divisible by 5")) {
        return "A number is divisible by 5 if its last digit is 0 or 5.";
    }

    return "";
}

/**
 * Extra pass: same block regex on preprocessed text (helps when layout was one long line).
 */
function parseQuestionsByNumberSplit(text) {
    const t = preprocessExamTextForMcq(text);
    const out = [];
    const re = /(?:^|\n)\s*(?:Q\s*)?(\d+)\s*[.)]\s*([\s\S]*?)(?=\n\s*(?:Q\s*)?\d+\s*[.)]\s|$)/gi;
    let m;
    while ((m = re.exec(t)) !== null) {
        let body = (m[2] || "").trim();
        if (!body) continue;
        const split = splitQuestionAndOptions(body);
        if (!split || split.options.length < 4) continue;
        const opts = split.options.slice(0, 4);
        let qText = split.question.replace(/^\d+\s*[.)]\s*/, "").trim() || split.question;
        out.push({
            question: qText,
            options: opts,
            answer: opts[0],
            hint: ""
        });
    }
    return out;
}

/** Split on lines that look like a new question number (helps messy PDFs). */
function parseQuestionsByLineBlocks(text) {
    const t = preprocessExamTextForMcq(text);
    const blocks = t.split(/\n(?=\s*\d+\s*[.)]\s)/);
    const out = [];
    for (const block of blocks) {
        const trimmed = block.trim();
        if (!/^\d+\s*[.)]/m.test(trimmed)) continue;
        const body = trimmed.replace(/^\s*\d+\s*[.)]\s*/, "").trim();
        if (!body) continue;
        const split = splitQuestionAndOptions(body);
        if (!split || split.options.length < 4) continue;
        const opts = split.options.slice(0, 4);
        let qText = split.question.replace(/^\d+\s*[.)]\s*/, "").trim() || split.question;
        out.push({ question: qText, options: opts, answer: opts[0], hint: "" });
    }
    return out;
}

function runAllParsersOnText(text) {
    let parsed = parseOcrTextToQuestions(text);
    if (parsed.length === 0) parsed = parseOcrTextToQuestionsRelaxed(text);
    if (parsed.length === 0) parsed = parseQuestionsByNumberSplit(text);
    if (parsed.length === 0) parsed = parseQuestionsByLineBlocks(text);
    return parsed;
}

async function extractTextFromPdfBuffer(buffer) {
    const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
    let full = "";
    for (let p = 1; p <= pdf.numPages; p++) {
        const page = await pdf.getPage(p);
        const tc = await page.getTextContent();
        full += pageTextFromPdfItems(tc) + "\n\n";
    }
    return normalizePdfText(full);
}

async function extractTextFromPdfViaCanvasOcr(buffer) {
    if (typeof Tesseract === "undefined") return "";
    const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
    let combined = "";
    for (let p = 1; p <= pdf.numPages; p++) {
        const page = await pdf.getPage(p);
        const viewport = page.getViewport({ scale: 2 });
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const renderTask = page.render({ canvasContext: ctx, viewport });
        await renderTask.promise;
        const {
            data: { text }
        } = await Tesseract.recognize(canvas, "eng", {
            logger: () => {}
        });
        combined += text + "\n";
    }
    return normalizePdfText(combined);
}

/**
 * Turn PDF bytes into `questions` + enable login when done.
 */
async function loadQuestionsFromPdfBuffer(buffer, statusEl, errEl, setReady) {
    if (statusEl) {
        statusEl.style.display = "";
        statusEl.textContent = "Reading text from PDF…";
    }

    let text = "";
    try {
        text = await extractTextFromPdfBuffer(buffer);
    } catch (e) {
        setReady(false, "Could not read this PDF file. Check that it is a valid PDF.");
        return;
    }

    text = preprocessExamTextForMcq(text);
    text = fixSplitQuestionNumberTen(text);
    let parsed = runAllParsersOnText(text);
    parsed = supplementQuestionsFromRawBlocks(text, parsed);
    parsed = patchOcrPdfQuestionsNineAndTen(parsed);
    parsed = ensureRetakeHintsForAllQuestions(parsed);

    if (parsed.length === 0) {
        if (statusEl) {
            statusEl.style.display = "";
            statusEl.textContent =
                "Could not read questions from PDF text — trying page OCR (may take a minute)…";
        }
        try {
            let ocrText = await extractTextFromPdfViaCanvasOcr(buffer);
            ocrText = preprocessExamTextForMcq(ocrText);
            ocrText = fixSplitQuestionNumberTen(ocrText);
            parsed = runAllParsersOnText(ocrText);
            parsed = supplementQuestionsFromRawBlocks(ocrText, parsed);
            parsed = patchOcrPdfQuestionsNineAndTen(parsed);
            parsed = ensureRetakeHintsForAllQuestions(parsed);
        } catch (e) {
            setReady(
                false,
                "OCR on PDF pages failed. Export the exam as a text-based PDF or add clear numbered MCQs."
            );
            return;
        }
    }

    if (parsed.length === 0) {
        questions = ensureRetakeHintsForAllQuestions(
            SAMPLE_QUESTIONS.map((q) => ({
                question: q.question,
                options: q.options.slice(),
                answer: q.answer,
                hint: q.hint || ""
            }))
        );
        resetAttemptArrays();
        timeLeft = examTimeSeconds();
        setReady(true, "");
        if (errEl) {
            errEl.style.display = "block";
            errEl.style.color = "#b36b00";
            errEl.innerHTML =
                "Could not read MCQs from this PDF (wrong layout or scanned image). <strong>Sample questions</strong> are loaded so you can still try the exam. Use numbered <strong>1. 2.</strong> and options <strong>a) b) c) d)</strong> in your PDF.";
        }
        return;
    }

    questions = parsed;
    resetAttemptArrays();
    timeLeft = examTimeSeconds();
    setReady(true, "");
}

async function loadExamFromPdf() {
    const statusEl = document.getElementById("examLoadStatus");
    const errEl = document.getElementById("examLoadError");
    const nameLabel = document.getElementById("pdfNameLabel");

    if (nameLabel) nameLabel.textContent = EXAM_PDF_FILENAME;

    function setReady(ok, errMsg) {
        if (errEl) {
            errEl.style.display = errMsg ? "block" : "none";
            errEl.textContent = errMsg || "";
            errEl.style.color = "#b00";
        }
        if (statusEl) {
            if (ok || errMsg) {
                statusEl.style.display = "none";
            } else {
                statusEl.style.display = "";
            }
        }
        const ready = Boolean(ok && questions.length > 0);
        enableLoginControls(ready);
    }

    if (typeof pdfjsLib === "undefined") {
        setReady(false, "PDF library failed to load. Check your network and refresh.");
        return;
    }

    pdfjsLib.GlobalWorkerOptions.workerSrc =
        "https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js";

    let buffer = null;
    try {
        const res = await fetch(EXAM_PDF_FILENAME, { cache: "no-store" });
        if (res.ok) buffer = await res.arrayBuffer();
    } catch (e) {
        buffer = null;
    }

    // Only use the embedded PDF when you are actually loading "ocr.pdf".
    if (!buffer && EXAM_PDF_FILENAME.toLowerCase() === "ocr.pdf") {
        buffer = arrayBufferFromEmbeddedOcrPdf();
    }

    if (!buffer) {
        setReady(
            false,
            "Could not load " +
                EXAM_PDF_FILENAME +
                " automatically. If you opened this page by double-clicking (file://), the browser blocks auto-loading PDFs. Run a local server in this folder (python -m http.server) and open http://localhost:8000."
        );
        return;
    }

    await loadQuestionsFromPdfBuffer(buffer, statusEl, errEl, setReady);
}

document.addEventListener("DOMContentLoaded", () => {
    loadExamFromPdf();
});

function saveResponse() {
    let responses = JSON.parse(localStorage.getItem("responses")) || [];

    responses.push({
        name: studentName,
        class: studentClass,
        score: score,
        total: questions.length,
        correct: correct,
        wrong: wrong,
        hintsUsed: hintCount,
        attempt: attempt,
        date: new Date().toLocaleString()
    });

    localStorage.setItem("responses", JSON.stringify(responses));
}

function startExam() {
    if (!questions.length) {
        alert("Questions are not ready yet. Refresh the page and wait for the exam to finish loading.");
        return;
    }

    let name = document.getElementById("username").value;
    let cls = document.getElementById("class").value;

    if (name === "" || cls === "") {
        alert("Please enter Name and Class");
        return;
    }

    let namePattern = /^[A-Za-z ]+$/;
    if (!namePattern.test(name)) {
        alert("Name should contain only letters");
        return;
    }

    studentName = name;
    studentClass = cls;
    isRetake = false;

    document.getElementById("loginPage").style.display = "none";
    document.getElementById("quizPage").style.display = "block";
    document.getElementById("timer").style.display = "block";

    timeLeft = examTimeSeconds();
    let timeSpan = document.getElementById("time");
    if (timeSpan) timeSpan.innerText = timeLeft;

    loadQuestion();
    startTimer();
}

function loadQuestion() {
    let q = questions[currentQuestion];

    document.getElementById("question").innerText =
        "Q" + (currentQuestion + 1) + ". " + q.question;

    let optionsHtml = "";

    q.options.forEach((opt) => {
        const safeVal = String(opt).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
        optionsHtml += `
            <label style="display:block; margin:8px 0;">
                <input type="radio" name="option" value="${escapeHtml(opt)}"
                onclick="checkAnswer('${safeVal}')">
                ${escapeHtml(opt)}
            </label>
        `;
    });

    if (isRetake && q.hint && String(q.hint).trim()) {
        optionsHtml += `
            <button type="button" class="btn-hint" onclick="showHint()"><span class="hint-btn-icon" aria-hidden="true" title="Hint">&#128161;</span> Show hint</button>
            <p id="hintText" class="hint-panel" style="display:none;"></p>
        `;
    }

    document.getElementById("options").innerHTML = optionsHtml;

    if (userAnswers[currentQuestion]) {
        let radios = document.getElementsByName("option");
        radios.forEach((r) => {
            if (r.value === userAnswers[currentQuestion]) {
                r.checked = true;
            }
        });
    }

    document.getElementById("warning").style.display = "none";

    updateButtons();
}

function checkAnswer(selected) {
    userAnswers[currentQuestion] = selected;
}

function showHint() {
    const el = document.getElementById("hintText");
    if (!el) return;
    const h = questions[currentQuestion].hint;
    el.innerHTML =
        '<span class="hint-label"><span class="hint-bulb" aria-hidden="true">&#128161;</span> Hint:</span> ' +
        escapeHtml(h);
    el.style.display = "block";

    if (!hintUsed[currentQuestion]) {
        hintUsed[currentQuestion] = true;
        hintCount++;
    }
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion < questions.length) loadQuestion();
}

function prevQuestion() {
    currentQuestion--;
    if (currentQuestion >= 0) loadQuestion();
}

function updateButtons() {
    let html = "";

    if (currentQuestion === 0) {
        html += `<button type="button" onclick="nextQuestion()">Next</button>`;
    } else if (currentQuestion === questions.length - 1) {
        html += `<button type="button" onclick="prevQuestion()">Previous</button>`;

        if (attempt < maxAttempts) {
            html += `<button type="button" onclick="submitQuiz()">Submit</button>`;
        } else {
            html += `<button type="button" onclick="finishExam()">Finish</button>`;
        }
    } else {
        html += `<button type="button" onclick="prevQuestion()">Previous</button>`;
        html += `<button type="button" onclick="nextQuestion()">Next</button>`;
    }

    document.getElementById("navButtons").innerHTML = html;
}

function submitQuiz() {
    for (let i = 0; i < userAnswers.length; i++) {
        if (userAnswers[i] === null) {
            currentQuestion = i;
            loadQuestion();

            let warn = document.getElementById("warning");
            warn.innerHTML = "<strong>!</strong> You missed this question!";
            warn.style.display = "block";
            return;
        }
    }

    correct = 0;
    wrong = 0;

    for (let i = 0; i < questions.length; i++) {
        if (userAnswers[i] === questions[i].answer) correct++;
        else wrong++;
    }

    score = correct;

    if (attempt < maxAttempts) {
        document.body.innerHTML = `
            <div class="result-wrap">
                <h2>${escapeHtml(studentName)}</h2>
                <h3>Score: ${correct} / ${questions.length}</h3>
                <p class="result-stat"><span class="sym sym-ok" title="Correct">&#10003;</span> Correct: ${correct}</p>
                <p class="result-stat"><span class="sym sym-bad" title="Wrong">&#10007;</span> Wrong: ${wrong}</p>
                <button type="button" onclick="retakeTest()">Retake Test</button>
                <button type="button" onclick="finishExam()">Finish</button>
            </div>
        `;
    } else {
        finishExam();
    }
}

function retakeTest() {
    attempt++;
    isRetake = true;

    if (timer) {
        clearInterval(timer);
        timer = null;
    }
    timeLeft = examTimeSeconds();

    userAnswers = new Array(questions.length).fill(null);
    hintUsed = new Array(questions.length).fill(false);
    hintCount = 0;

    currentQuestion = 0;
    score = 0;

    document.body.innerHTML = `
        <div class="header">Retake Exam</div>

        <div id="timer">
            Time Left: <span id="time">${timeLeft}</span> sec
        </div>

        <div class="quiz-container">
            <h2 id="question"></h2>
            <p id="warning" style="color:red;"></p>
            <div id="options"></div>
            <div id="navButtons"></div>
        </div>
    `;

    loadQuestion();
    startTimer();
}

function finishExam() {
    if (timer) {
        clearInterval(timer);
        timer = null;
    }

    saveResponse();

    document.body.innerHTML = `
        <div class="result-wrap">
            <h2 class="title-done">Exam Completed</h2>
            <h3>Thank you, ${escapeHtml(studentName)}!</h3>
            <p><b>Class:</b> ${escapeHtml(studentClass)}</p>
            <h2>Final Score: ${correct} / ${questions.length}</h2>
            <p class="result-stat"><span class="sym sym-ok" title="Correct">&#10003;</span> Correct answers: ${correct}</p>
            <p class="result-stat"><span class="sym sym-bad" title="Wrong">&#10007;</span> Wrong answers: ${wrong}</p>
            <p class="result-stat"><span class="sym sym-hint" title="Hints used">&#128161;</span> Hints used: ${hintCount}</p>
            <br>
            <button type="button" onclick="viewResponses()">View Responses</button>
        </div>
    `;
}

function viewResponses() {
    let responses = JSON.parse(localStorage.getItem("responses")) || [];

    let html = `<h2>Total Responses: ${responses.length}</h2>`;

    responses.forEach((r, i) => {
        html += `
            <div style="border:1px solid #ccc; margin:10px; padding:10px;">
                <p><b>${i + 1}. ${escapeHtml(r.name)}</b> (${escapeHtml(r.class)})</p>
                <p>Score: ${r.score}/${r.total}</p>
                <p>Correct: ${r.correct}</p>
                <p>Wrong: ${r.wrong}</p>
                <p>Hints Used: ${r.hintsUsed}</p>
                <p>Attempt: ${r.attempt}</p>
                <p>Date: ${escapeHtml(r.date)}</p>
            </div>
        `;
    });

    html += `<button type="button" onclick="location.reload()">Back</button>`;

    document.body.innerHTML = html;
}

function startTimer() {
    if (timer) return;

    timer = setInterval(() => {
        timeLeft--;
        let t = document.getElementById("time");
        if (t) t.innerText = timeLeft;

        if (timeLeft <= 0) {
            clearInterval(timer);
            timer = null;
            submitQuiz();
        }
    }, 1000);
}
